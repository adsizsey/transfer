#!/bin/bash
pip install maturin